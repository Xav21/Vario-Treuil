package com.chavanet.variotreuil;

import android.Manifest;
import android.app.ActivityManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.sairamkrishna.myapplication.R;

import androidx.core.app.ActivityCompat;
import pl.pawelkleczkowski.customgauge.CustomGauge;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Set;
import java.util.UUID;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.location.Location;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;


public class MainActivity extends AppCompatActivity implements LocationListener {
    final int gpsAccessRequest = 1;

    CustomGauge g1Tv;
    TextView altitudeTv;
    TextView txTv;
    TextView lngTv;
    TextView txSpeedTv;
    TextView errorGPSTv;
    TextView errorTv;
    TextView logTv;

    BluetoothAdapter mBluetoothAdapter;
    BluetoothSocket mmSocket;
    BluetoothDevice mmDevice;
    OutputStream mmOutputStream;
    InputStream mmInputStream;
    Thread workerThread;
    Thread connectToV;
    byte[] readBuffer;
    int readBufferPosition;

    volatile boolean stopWorker;
    private PowerManager.WakeLock wl;
    private static Context context;
    private boolean isConnected = false;
    ToneGenerator toneGenerator = new ToneGenerator(AudioManager.STREAM_ALARM, 100);

    String varioName = "VARIO-TREUIL";

    float fPressionZero = -1;
    float fLastAltitude = -1;
    float fLastPression = -1;

    float fNbTours = 0;
    float fNbToursOffset = 0;

    Context ctx;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.i("onCreate", "onCreate...");

        super.onCreate(savedInstanceState);
        MainActivity.context = getApplicationContext();
        setContentView(R.layout.activity_main);

         // Hide action/menu bar
        this.getSupportActionBar().hide();

        // Screen objects
        altitudeTv = findViewById(R.id.altitude);
        txTv = findViewById(R.id.tx);
        lngTv = findViewById(R.id.lng);
        txSpeedTv = findViewById(R.id.speed);
        g1Tv = findViewById(R.id.gauge1);
        errorTv = findViewById(R.id.error);
        errorGPSTv = findViewById(R.id.errorGPS);
        logTv = findViewById(R.id.log);

        // Bluetooth Event
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        registerReceiver(mReceiver, filter);


        // GPS
        Log.i("onCreate", "GPS...");
        if (checkSelfPermission(ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[] {  ACCESS_FINE_LOCATION  }, gpsAccessRequest);
        } else {
            LocationManager lm = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
            onLocationChanged(null);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (findBT()) {
            if (findVario()) {
                connectToVario();
            } else
            {
                Intent intentOpenBluetoothSettings = new Intent();
                intentOpenBluetoothSettings.setAction(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
                startActivity(intentOpenBluetoothSettings);
            }
        }


    }
    @Override
    protected void onDestroy() {
        Log.i("onDestroy", "onDestroy...");
        super.onDestroy();
        unregisterReceiver(mReceiver);

        try {
            mmSocket.close();
        }
        catch (IOException ex) {}

        //stopService(mVarioSoundIntent);


    }
    private boolean isMyServiceRunning(Class VarioSoundService) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (VarioSoundService.getName().equals(service.service.getClassName())) {
                Log.i ("isMyServiceRunning?", true+"");
                return true;
            }
        }
        Log.i ("isMyServiceRunning?", false+"");
        return false;
    }

    // Create a BroadcastReceiver for bluetooth related checks
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            Log.i("xavier ", "==>" + action + " on " + device.getName() + "(" + device + ")");

            //We don't want to reconnect to already connected device
            if (isConnected == false) {
                // When discovery finds a device
                if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                    // Get the BluetoothDevice object from the Intent

                    // Check if the found device is one we had comm with
                    if (device.getName().equals(varioName) == true) {
                        connectToVario();
                    }
                }
            }
            if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                // Check if the connected device is one we had comm with
                if (device.getName().equals(varioName) == true) {
                    isConnected = true;
                }
            } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {

                // Check if the connected device is one we had comm with
                if (device.getName().equals(varioName) == true) {
                    isConnected = false;
                    connectToVario();
                }
            }
        }
    };

    private void setSound(final Integer tone,final Integer duration){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                toneGenerator.startTone(tone, duration);
            }
        });
    }

    private void setText(final TextView text,final String value){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                text.setText(value);
            }
        });
    }

    private void setGraphValue(final CustomGauge text,final float value){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                text.setValue((int) (value * 10));
            }
        });
    }

    private void setToast(final String value){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(),value,Toast.LENGTH_LONG).show();
            }
        });
    }
    void connectToVario() {
    //new ConnectThread(device)
        final Handler handler = new Handler();

        connectToV = new Thread(new Runnable() {
            public void run() {
                while (!isConnected) {
                    setText(errorTv,"Tentative de connexion avec " + varioName);
                    setText(txTv,"??");
                    setText(lngTv,"??");
                    setText(altitudeTv,"??");
                    setGraphValue(g1Tv,20);

                    if (findBT() ) {
                        if (findVario()) {
                            if (openBT()) {
                                isConnected = true;
                                setToast("Connecté avec " + varioName);
                                setText(errorTv, varioName + " connecté");
                                setText(txTv,"--");
                                setText(altitudeTv,"--");
                                setGraphValue(g1Tv,0);
                            } else {
                                setToast("Erreur de connexion " + varioName);
                                setText(errorTv, "Erreur de connexion avec " + varioName);
                            }

                        } else {
                            setToast(varioName + " non appairé avec cet appareil!");
                            setText(errorTv, varioName + " non appairé avec cet appareil");
                        }
                    }
                }
            }
        });
        connectToV.start();
    }

    public boolean findBT() {
        boolean ret = true;
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            ret = false;
            setToast(varioName + "Aucun adaptateur Bluetooth sur cet appareil!");
            setText(errorTv, "Aucun adaptateur Bluetooth sur cet appareil!");
        }

        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBluetooth, 0);
        }
        return ret;
    }

    public boolean findVario() {
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                if (device.getName().equals(varioName)) {
                    mmDevice = device;
                    Log.i("findVario", varioName + " trouvé sur le réseau BT.");
                    return true;
                }
            }
        }

        return false;
    }

    public boolean openBT() {
        boolean ret = false;
        try {
            Log.i("openBT", "init...");
            UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); //Standard SerialPortService ID
            mmSocket = mmDevice.createRfcommSocketToServiceRecord(uuid);

            mmSocket.connect();

            mmOutputStream = mmSocket.getOutputStream();
            mmInputStream = mmSocket.getInputStream();

            beginListenForData();
            ret = true;
        }
        catch(IOException ex){
            ret=false;
            Log.i("xavier ", "openBT exception"+ ex);
        }
        return ret;
    }

    void beginListenForData() {

        stopWorker = false;
        readBufferPosition = 0;
        readBuffer = new byte[1024];

        Log.i("xavier ", "beginListenForData");
        workerThread = new Thread(new Runnable() {
            public void run() {
                while (!Thread.currentThread().isInterrupted() && !stopWorker) {
                    try {
                        int bytesAvailable = mmInputStream.available();
                        // Reception 13 bytes. Format : code='V' - Vario:float - nbTours:float - pression:float
                        if (bytesAvailable == 16 ) {

                            byte[] packetBytes = new byte[bytesAvailable];
                            mmInputStream.read(packetBytes);

                            // Vérification du code 'V'
                            if (packetBytes[0] == 0x56) {
                                byte[] data = new byte[4];

                                // Decodage nombre de tours de bobine

                                for (int i = 8; i < 12; i++) {
                                    data[i - 8] = packetBytes[i];
                                }
                                final float nbTours = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).getFloat();
                                setText(lngTv, Integer.toString((int) (nbTours - fNbToursOffset)));
                                fNbTours = nbTours;

                                // Decodage taux de montée
                                for (int i = 4; i < 8; i++) {
                                    data[i-4] = packetBytes[i];
                                }
                                final float vario = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).getFloat();

                                String txtLog ="";
                                String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

                                // vario=-99 ==> pas de connection LORA
                                if (vario == -99) {
                                    setText(txTv, "??");
                                    setText(altitudeTv, "??");
                                    setGraphValue(g1Tv, 20);
                                    txtLog= currentTime + ": Vario=" +vario + " nbTours=" + nbTours + " Pression=nc";
                                } else {
                                    // Affichage du taux de montée
                                    setText(txTv, Float.toString(vario));
                                    if (vario < 0) {
                                        setGraphValue(g1Tv, 0);
                                    } else {
                                        setGraphValue(g1Tv, vario);
                                    }

                                    // Decodage pression
                                    for (int i = 12; i < 16; i++) {
                                        data[i - 12] = packetBytes[i];
                                    }
                                    final float pression = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).getFloat();
                                    // Mémorisation pression local au décollage
                                    if (fPressionZero == -1) {
                                        fPressionZero = pression;
                                        fLastAltitude = -1;
                                    }
                                    // Calcul altitude
                                    float alt = (fPressionZero - pression) / (float) 11.7;
                                    if (pression > 100 && fLastAltitude <= alt) {
                                        fLastAltitude = alt;
                                        setText(altitudeTv, Integer.toString((int)alt) + " m");
                                    } else {
                                        setText(altitudeTv, Integer.toString((int)fLastAltitude) + " m");
                                    }

                                    txtLog= currentTime + ": Vario=" +vario + " nbTours=" + nbTours + " Pression=" + pression;
                                }

                                // Log
                                Log.i("beginListenForData", bytesAvailable + "=>" + String.format("%02x", packetBytes[0]) + ":" + String.format("%02x", packetBytes[1]) + ":" + String.format("%02x", packetBytes[2]) + ":" + String.format("%02x", packetBytes[3]) + ":" + String.format("%02x", packetBytes[4]) );
                                setText(logTv,txtLog);


                            }
                        }
                    } catch (IOException ex) {
                        Log.i("beginListenForData", " exception " + ex);
                        stopWorker = true;
                    }
                }
            }
        });

        workerThread.start();
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location  == null) {
            errorGPSTv.setText("En attente de la position GPS");
        } else {
            errorGPSTv.setText("GPS Ok");
            txSpeedTv.setText(Math.round(location.getSpeed() * 3.6 )+"");
        }
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {
        Log.i("onStatusChanged", "s="+s+ " i="+i+" bundle="+bundle);
    }

    @Override
    public void onProviderEnabled(String s) {
        Log.i("onProviderEnabled", "s="+s);
        setToast("GPS en ligne!");
        errorGPSTv.setText("En attente de la position GPS");

    }

    @Override
    public void onProviderDisabled(String s) {
        Log.i("onProviderDisabled", "s="+s);
        setToast("Perte GPS!");
        errorGPSTv.setText("GPS hors ligne");
        txSpeedTv.setText("??");

    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions,int[] grantResults) {
        Log.i("onRequestPermissionsR", "requestCode="+requestCode+ " permission="+permissions+" grantResults="+grantResults);
        switch (requestCode) {
            case gpsAccessRequest: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    LocationManager lm = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
                    onLocationChanged(null);
                } else {
                    setToast("Accès GPS refusé!");
                    errorGPSTv.setText("Accès GPS refusé");
                }
                return;
            }
        }
    }

    public void onClicklng (View v) {
        Log.i("onClicklng", "onClicklng");
        fNbToursOffset = fNbTours;
    }
   public void onClickAltitude (View v) {
        Log.i("onClickAltitude", "onClickAltitude");
       fPressionZero = -1;

   }
}

