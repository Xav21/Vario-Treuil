package fr.chavanet.variotreuilandroid;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;


import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class BilanActivity extends AppCompatActivity {
    BilanPagerAdapter bilanPagerAdapter;
    ViewPager viewPager;
    TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bilan_activity);

        viewPager = findViewById(R.id.viewBilanPager);
        tabLayout = findViewById(R.id.tabBilan);

        setPagerAdapter();
        setTabLayout();
    }

    private void setPagerAdapter(){
        bilanPagerAdapter = new BilanPagerAdapter(getSupportFragmentManager(),1);
        viewPager.setAdapter(bilanPagerAdapter);
    }
    private void setTabLayout() {
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setText("Bilan");
        tabLayout.getTabAt(1).setText("Treuillées");
        tabLayout.getTabAt(2).setText("Vols");


    }

}
