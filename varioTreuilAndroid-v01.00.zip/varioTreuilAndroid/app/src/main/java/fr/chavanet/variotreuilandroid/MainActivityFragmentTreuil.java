package fr.chavanet.variotreuilandroid;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Application;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.PagerAdapter;

public class MainActivityFragmentTreuil extends Fragment {

    static final String TAG = "xavier/MainFragmentTreuil";
    private static final int REQUEST_ACTIVITY = 34;
    private static final int RESULT_CODE = 0;

    MqttAndroidClient mqttAndroidClient;

    // Les activités
    Intent intentPiloteActivity;

    // screen obj
    ListView lvListePilote;
    PiloteAdapter piloteAdapter;
    List<PiloteModel> listePilote = new ArrayList<>();

    // Préférences
    Preferences prefs;
    Integer primaryColor;
    boolean savedMode = true;
    boolean modeEnregistrement = true;

    public MainActivityFragmentTreuil(boolean mode) {
        modeEnregistrement = mode;
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        // Set fragment theme
        prefs = new Preferences(getContext());
        return inflater.inflate(R.layout.activity_main_treuil, container, false);
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG,  "onPause");

        // Stop MQTT
        mqttUnSubcribe("#");

        // Clear pilote list
        listePilote.clear();
        piloteAdapter.notifyDataSetChanged();
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG,  "onResume" );
        Toast.makeText(getContext(), "Mode treuil sélectionné", Toast.LENGTH_SHORT).show();

        // Sauvegarde de l'activité active
        prefs = new Preferences(getContext());
        prefs.setModeTreuil();



        // Start MQTT
        setupMQTT();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Log.d(TAG,  "onViewCreated");
        Bundle args = getArguments();
        intentPiloteActivity = new Intent(getActivity(), PiloteActivity.class);

        // Chargement des préferences
        prefs = new Preferences(getContext());

        // Gestion de la liste de consignes
        lvListePilote = view.findViewById(R.id.listePilote);
        piloteAdapter = new PiloteAdapter(getContext(), listePilote);
        lvListePilote.setAdapter(piloteAdapter);

        // Sur selection d'un pilote
        lvListePilote.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d(TAG, listePilote.get(i).getPilote() + " selectionné.");
                mqttUnSubcribe("#");

                Intent intentTreuilActivity = new Intent(getActivity(), TreuilActivity.class);
                Bundle b = new Bundle();
                b.putString("id", listePilote.get(i).getId());
                b.putString("pilote", listePilote.get(i).getPilote());
                b.putString("club", prefs.getClub());
                intentTreuilActivity.putExtras(b);
                startActivityForResult(intentTreuilActivity, REQUEST_ACTIVITY);
            }
        });



    }

    /**
     * **********************************************************************
     * setupMQTT
     * ***********************************************************************
     **/
    public void setupMQTT ()  {
        try {
             if (mqttAndroidClient == null || !mqttAndroidClient.isConnected()) {
                // Start MQTT
                String serverUri = "ssl://" + prefs.getMqttServerName() + ":" + prefs.getMqttServerPort();

                String clientId;
                clientId = prefs.getUniqueId();
                Log.d(TAG, "setupMQTT=>" + serverUri + " " + clientId);

                mqttAndroidClient = new MqttAndroidClient(getContext(), serverUri, clientId, new MemoryPersistence(), MqttAndroidClient.Ack.AUTO_ACK);
                MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
                mqttConnectOptions.setAutomaticReconnect(true);
                mqttConnectOptions.setCleanSession(true);
                mqttConnectOptions.setUserName(prefs.getMqttUser());
                mqttConnectOptions.setPassword(prefs.getMqttPswd().toCharArray());

                mqttAndroidClient.connect(mqttConnectOptions, null, new IMqttActionListener() {
                    @Override
                    public void onSuccess(IMqttToken asyncActionToken) {
                        Log.d(TAG, "setupMQTT/onSuccess");
                        DisconnectedBufferOptions disconnectedBufferOptions = new DisconnectedBufferOptions();
                        disconnectedBufferOptions.setBufferEnabled(true);
                        disconnectedBufferOptions.setBufferSize(100);
                        disconnectedBufferOptions.setPersistBuffer(false);
                        disconnectedBufferOptions.setDeleteOldestMessages(true);
                        mqttAndroidClient.setBufferOpts(disconnectedBufferOptions);

                        // subscribe
                        mqttSubcribe(prefs.getClub() + "/#");
                    }

                    @Override
                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                        Log.e(TAG, "MQTT Connect failed:" + exception.toString());
                        exception.printStackTrace();
                        Toast.makeText(getContext(), exception.toString(), Toast.LENGTH_LONG).show();

                    }
                });
            } else {
                 // subscribe
                 mqttSubcribe(prefs.getClub() + "/#");
             }

        } catch (MqttException e) {
            e.printStackTrace();
            Toast.makeText(getContext(), e.toString(), Toast.LENGTH_LONG).show();
        }

    }
    /***********************************************************************
     *  mqttUnSubcribe
     ***********************************************************************/
    public void mqttUnSubcribe(String topic) {
        try {
             Log.d(TAG, "mqttUnSubcribe=>" + mqttAndroidClient.getServerURI() + " " + mqttAndroidClient.getClientId() + " topic=" + topic);
             mqttAndroidClient.unsubscribe(topic);
             mqttAndroidClient.setCallback(null);
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG,e.toString());
            //Toast.makeText(getContext(), e.toString(), Toast.LENGTH_LONG).show();
        }

    }

    /***********************************************************************
     *  mqttSubcribe
     ***********************************************************************/
    public void mqttSubcribe(String topic) {
        try {
            Log.d(TAG,"mqttSubcribe=>" + mqttAndroidClient.getServerURI() +  " " + mqttAndroidClient.getClientId() + " topic="+ topic);
            mqttAndroidClient.subscribe(topic, 0,null);

        } catch (MqttException e) {
            Log.e(TAG,e.toString());
            e.printStackTrace();
            Toast.makeText(getContext(), e.toString(), Toast.LENGTH_LONG).show();
        }

        // MQTT callbacks
        mqttAndroidClient.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
                Log.d(TAG, "MQTT connectComplete");
            }

            @Override
            public void connectionLost(Throwable throwable) {
                Log.e(TAG, "MQTT connectionLost");
                try {
                    mqttAndroidClient.connect();
                } catch (MqttException e) {
                    Log.e(TAG,e.toString());
                    e.printStackTrace();
                    Toast.makeText(getContext(), e.toString(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) {
                String payload = new String(message.getPayload());
                Log.d(TAG, "MQTT topic: " + topic + ", msg: " + payload);
                try {
                    JSONObject jObject = new JSONObject(payload);
                    int idx = piloteInList(jObject.getString("id"));
                    if ( idx == -1 ) {
                        // Pas trouvé ajour
                        listePilote.add(0, new PiloteModel(jObject.getString("id"),
                                jObject.getString("pilote"),
                                jObject.getString("ptv"),
                                jObject.getString("voile"),
                                jObject.getString("typevol")));

                    } else {
                        // Trouvé, mise à jour
                        PiloteModel item = listePilote.get(idx);
                        item.setPtv(jObject.getString("ptv"));
                        item.setPilote(jObject.getString("pilote"));
                        item.setVoile(jObject.getString("voile"));
                        item.setTypeVol(jObject.getString("typevol"));
                    }
                    piloteAdapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    Log.e(TAG,e.toString());
                    e.printStackTrace();
                    Toast.makeText(getContext(), e.toString(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.d(TAG, "MQTT msg delivered");
            }
        });
    }

    /***********************************************************************
     * piloteInList :
     * ***********************************************************************
     **/
    int piloteInList(String id) {
        PiloteModel piloteArray;
        int retCode = -1;
        for(int i=0;  i<listePilote.size(); i++) {
            piloteArray = listePilote.get(i);
            if (piloteArray.getId().equals(id)) {
                retCode = i;
            }
        }
        return retCode;
    }
}
