package fr.chavanet.variotreuilandroid;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.OnNmeaMessageListener;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.preference.PreferenceManager;
import pl.pawelkleczkowski.customgauge.CustomGauge;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static com.android.volley.toolbox.Volley.newRequestQueue;

@RequiresApi(api = Build.VERSION_CODES.N)
public class TreuilActivity extends AppCompatActivity implements OnNmeaMessageListener  {
    private static final String TAG = "xavier/TreuilActivity";

    String pilote;
    String club;
    String id = "";

    // Screen obj
    TextView tvTx;
    TextView tvQfe;
    TextView tvQnh;
    TextView tvVitesseVehicule;
    CustomGauge tvGauge1;
    TextView tvPilote;
    TextView tvVoile;
    TextView tvPTV;
    TextView tvLog;
    TextView tvLigneDeroule;
    RadioButton tvActivite;
    TextView tvTypeVol;
    TextView tvTypeGPS;
    TextView tvTypeGPSPilote;
    TextView tvAngleLigne;

    Boolean mneaAvailable = false;

    Double latitudePilote;
    Double longitudePilote;
    Double altitudePilote;
    Double qfePilote;


    // Gestion de l'enregistrement d'une treuillée
    // Vitesse voiture supérieur à seulVitesseVoiture et franchissement de seuilQFE
    int lastQFE = 0;
    long lastTime = 0;
    int seuilQFE;           // Hauteur à laquelle on déclare une treuilée.
    int seulVitesseVoiture; // Vitesse voiture à laquelle on déclare une treuilée.
    int seuilTemps;         // Temps mini entre 2 treuillées en ms.
    String treuilleur;

    // GPS
    LocationManager lm;
    LocationListener locationListener;
    double vitesseVehicule = 0;
    final int gpsAccessRequest = 1;

    // MQTT
    MqttAndroidClient mqttAndroidClient;

    //Preferences
    Preferences prefs;
    Boolean modeEnregistrement = false;

    /***********************************************************************
     *  onCreate
     ***********************************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate...");
        // Récupération des préférences
        prefs = new Preferences(this);
        seuilQFE = prefs.getSeuilQFE();
        seuilTemps = prefs.getSeuilTemps();
        seulVitesseVoiture = prefs.getSeuilVitesseVoiture();
        treuilleur = prefs.getTreuileur();

        // Récupération des paramètres
        Bundle b = getIntent().getExtras();
        if(b != null) {
            id = b.getString("id");
            pilote = b.getString("pilote");
            club = b.getString("club");
        }

        // Creation view
        if (prefs.isModeEnregistrement()) {
            setTheme(R.style.AppTheme);
        } else {
            setTheme(R.style.piloteTheme);
        }
        setContentView(R.layout.treuil_activity);

        // Screen objects
        tvTx = findViewById(R.id.tx);
        tvQfe = findViewById(R.id.qfe);
        tvQnh = findViewById(R.id.qnh);
        tvVitesseVehicule = findViewById(R.id.vitesseVehicule);
        tvGauge1 = findViewById(R.id.gauge1);
        tvPilote = findViewById(R.id.pilote);
        tvPilote.setText(pilote);
        tvVoile = findViewById(R.id.voile);
        tvPTV = findViewById(R.id.ptv);
        tvActivite = findViewById(R.id.activite);
        tvTypeVol = findViewById(R.id.treuilTypeVol);
        tvLigneDeroule = findViewById(R.id.ligneDeroule);
        tvTypeGPS = findViewById(R.id.typeGPS);
        tvTypeGPSPilote = findViewById(R.id.typeGPSPilote);
        tvAngleLigne = findViewById(R.id.angleLigne);

    }

    /***********************************************************************
     *  onStart
     ***********************************************************************/
    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG ,"onStart...");

        // Statup MQTT cnx
        setupMQTT();

        // Vitesse véhicule à 0
        vitesseVehicule = 0;

        // Set QFE to 0
        tvQfe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // todo : implementation reset QFE = 0 à faire
            }
        });

        // GPS
        if (checkSelfPermission(ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[] {  ACCESS_FINE_LOCATION  }, gpsAccessRequest);
        } else {
            lm = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
            locationListener = new MyLocationListener();
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0,locationListener);

            // Mnea GPS data pour avoir l'altitude corrigée par la GEOIDE au lieu de la projectin wgs84.
            // Fonctionne à partir de l'API 30
            lm.addNmeaListener(this);
        }
    }
    /**
     * **********************************************************************
     * onDestroy
     * ***********************************************************************
     **/
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG ,"onDestroy...");
    }
    /**
     * **********************************************************************
     * onStop
     * ***********************************************************************
     **/
    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG ,"onStop...");
        lm.removeUpdates(locationListener);
        lm.removeNmeaListener(this);

        try {
            mqttAndroidClient.unsubscribe("#" );
            mqttAndroidClient.setCallback(null);
            mqttAndroidClient.disconnect();
        } catch (MqttException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
        }

    }


    /***********************************************************************
     *  mqttSubcribe
     ***********************************************************************/
    public void mqttSubcribe(String topic) {

        try {
            Log.d(TAG, "mqtt sub=>" + topic);
            mqttAndroidClient.subscribe(topic, 0,null);
        } catch (MqttException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
        }

        // MQTT callbacks
        mqttAndroidClient.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
                Log.d(TAG, "MQTT connectComplete");
            }

            @Override
            public void connectionLost(Throwable throwable) {
                Log.e(TAG, "MQTT connectionLost");
                try {
                    mqttAndroidClient.connect();
                } catch (MqttException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) {
                String payload = new String(message.getPayload());
                Log.i(TAG, "MQTT topic: " + topic + ", msg: " + payload);
                try {
                    // Mise à jour de l'écran
                    //========================
                    JSONObject jsonReceived = new JSONObject(payload);
                    double tx = Double.parseDouble(jsonReceived.getString("tx"));
                    tx = (double) Math.round(tx*10) / 10;
                    tvTx.setText(Double.toString(tx));
                    if (tx < 0 ) tx = 0.0;
                    tvGauge1.setValue((int)(tx*10));
                    tvVoile.setText(jsonReceived.getString("voile"));
                    tvPilote.setText(jsonReceived.getString("pilote"));
                    tvQfe.setText(jsonReceived.getString("qfe"));
                    tvQnh.setText(jsonReceived.getString("qnh"));
                    tvPTV.setText(jsonReceived.getString("ptv"));
                    tvTypeVol.setText(jsonReceived.getString("typevol"));
                    GPSUtils gpsUtil = new GPSUtils("");
                    // si pas de tramme nmea (cas de l'émulateur android studio)
                    try {
                        String txt = "GPS pilote >" + jsonReceived.getString("typegps") +
                                " - sat:" + jsonReceived.getString("nbsat") +
                                " - qualité " + gpsUtil.getGPSQualityText(Double.valueOf(jsonReceived.getString("hdop")));
                        tvTypeGPSPilote.setText(txt);
                    } catch (Exception e) {}


                    if (tvActivite.isChecked()){
                        tvActivite.setChecked(false);
                    } else {
                        tvActivite.setChecked(true);
                    }

                    // Stockage localisation du pilote
                    latitudePilote = Double.valueOf(jsonReceived.getString("lat"));
                    longitudePilote = Double.valueOf(jsonReceived.getString("long"));
                    altitudePilote = Double.valueOf(jsonReceived.getString("qnh"));
                    qfePilote = Double.valueOf(jsonReceived.getString("qfe"));


                    // Enregistrement des treuillées
                    //===============================
                    int qfe = Integer.parseInt(jsonReceived.getString("qfe"));
                    if ( modeEnregistrement &&
                            qfe >= seuilQFE &&
                            qfe > lastQFE &&
                            lastQFE < seuilQFE &&
                            vitesseVehicule >= seulVitesseVoiture &&
                            lastTime + seuilTemps < System.currentTimeMillis()) {

                        // Enregistrement de la treuillée
                        lastTime = System.currentTimeMillis();
                        Toast.makeText(getApplicationContext(),"Treuillée enregistrée.", Toast.LENGTH_LONG).show();
                        JSONObject jsonEnregistrement = new JSONObject();
                        jsonEnregistrement.put("action","inserttreuille");
                        jsonEnregistrement.put("idpilote",jsonReceived.getString("id"));
                        jsonEnregistrement.put("pilote",jsonReceived.getString("pilote"));
                        jsonEnregistrement.put("idtreuilleur",prefs.getUniqueId());
                        jsonEnregistrement.put("treuilleur",treuilleur);
                        jsonEnregistrement.put("voile",jsonReceived.getString("voile"));
                        jsonEnregistrement.put("ptv",jsonReceived.getString("ptv"));
                        jsonEnregistrement.put("typevol",jsonReceived.getString("typevol"));
                        jsonEnregistrement.put("club",prefs.getClub());

                        sendData(jsonEnregistrement);
                    }
                    lastQFE = qfe;

                } catch (JSONException e) {
                    Log.e(TAG, e.toString());
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.d(TAG, "MQTT msg delivered");
            }
        });
    }
    /**
     * **********************************************************************
     * Listener class to get coordinates
     * ***********************************************************************
     **/
    private class MyLocationListener implements LocationListener {

        @Override
        public void onLocationChanged(Location loc) {
            vitesseVehicule = loc.getSpeed() * 3.6;
            tvVitesseVehicule.setText(String.valueOf((int) vitesseVehicule));
            if (!mneaAvailable) {
                calculLongueurDevide (loc.getAltitude(),loc.getLongitude());
            }
        }

        @Override
        public void onProviderDisabled(String provider) {}

        @Override
        public void onProviderEnabled(String provider) {}

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {}
    }

    /**
     * **********************************************************************
     * Listener to get nmea GPS data and display it
     * Format nmea message
     *       $GNGGA,165819.00,4718.771268,N,00500.584520,E,1,12,0.5,250.4,M,48.0,M,,*75
     * ***********************************************************************
     **/
    @Override
    public void onNmeaMessage(String message, long timestamp) {
        mneaAvailable = true;
        GPSUtils gpsUtils = new GPSUtils(message);
        if (gpsUtils.isValid()){
            calculLongueurDevide (gpsUtils.getLatGPS(),gpsUtils.getLongGPS());
            String txt = "GPS treuil >" + gpsUtils.getTypeGPS() +
                    " - sat:" + gpsUtils.getNbSatellites() +
                    " - qualité " + gpsUtils.getGPSQualityText(gpsUtils.getHDOP());
            tvTypeGPS.setText(txt);
        }
    }
    /*****************************************
     *
     ******************************************/
    public void calculLongueurDevide( Double latitude, Double longitude) {
        if (latitudePilote != null && longitudePilote != null && altitudePilote != null) {
            try {
                Double rLat = Math.toRadians(latitude);
                Double rLongRad = Math.toRadians(longitude);
                Double rLatPilote = Math.toRadians(latitudePilote);
                Double rLongPilote = Math.toRadians(longitudePilote);

                int dMin = prefs.getDistanceMiniAffichage();

                // Distance au sol par calcul "Loi des sinus"
                Double dSol = 6371 * Math.acos(Math.sin(rLat) * Math.sin(rLatPilote) + Math.cos(rLat) * Math.cos(rLatPilote) * Math.cos(rLongPilote - rLongRad));
                dSol = dSol * 1000;

                // Integration de la hauteur
                Double dAir = Math.sqrt(Math.pow(dSol, 2) + Math.pow(qfePilote, 2));
                Integer i = dAir.intValue();

                // Affichage longueur dévidée
                if (i > dMin) {
                    tvLigneDeroule.setText(i.toString());
                    // Calcul angle du câble & longuer dévidée
                    Double angle = Math.toDegrees(Math.atan(qfePilote/dSol));
                    Integer iAngle= angle.intValue();
                    tvAngleLigne.setText(iAngle.toString());
                } else {
                    tvLigneDeroule.setText("--");
                    tvAngleLigne.setText("--");
                }


            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
            }
        }
    }

    /*****************************************
     * senData to server via REST
     * @param jsonString
     ******************************************/
    public void sendData(final JSONObject jsonString) {
        RequestQueue mRequestQueue;
        StringRequest mStringRequest;

        mRequestQueue = newRequestQueue(this);

        final HTTPLinker httpLinker = new HTTPLinker(this);

        //String Request initialized
        mStringRequest = new StringRequest(Request.Method.POST, httpLinker.getURL() , new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d(TAG, response);
                try {
                    JSONObject jObject = new JSONObject(response);
                    if (jObject.getInt("retCode") != 1) {
                        Log.e(TAG, "Erreur d'enregistrement de la treuillée :" + jObject.getString("errorText"));
                        Toast.makeText(getApplicationContext(),jObject.getString("errorText"), Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(),"Treuillée enregistrée.", Toast.LENGTH_LONG).show();
                    }
                }
                catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Erreur d'enregistrement de la treuillée :" + error.toString());
                Toast.makeText(getApplicationContext(),"Erreur d'enregistrement de la treuillée :" + error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            //This is for Headers If You Needed
            @Override
            public Map<String, String> getHeaders()  {
                String credentials = httpLinker.getUser() + ":" + httpLinker.getPassword() ;
                String base64EncodedCredentials = Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Basic " + base64EncodedCredentials);
                return headers;
            }
            @Override
            public Map<String, String> getParams()  {
                Map<String, String> params = new HashMap<>();
                params.put("param", jsonString.toString());
                return params;
            }
        };

        mRequestQueue.add(mStringRequest);

    }
    /**
     * **********************************************************************
     * setupMQTT
     * ***********************************************************************
     **/
    public void setupMQTT ()  {
        try {
            if (mqttAndroidClient == null || !mqttAndroidClient.isConnected()) {
                // Start MQTT
                String serverUri = "ssl://" + prefs.getMqttServerName() + ":" + prefs.getMqttServerPort();

                String clientId;
                clientId = prefs.getUniqueId() + "-treuil";
                Log.d(TAG, "setupMQTT=>" + serverUri + " " + clientId);

                mqttAndroidClient = new MqttAndroidClient(getApplicationContext(), serverUri, clientId, new MemoryPersistence(), MqttAndroidClient.Ack.AUTO_ACK);
                MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
                mqttConnectOptions.setAutomaticReconnect(true);
                mqttConnectOptions.setCleanSession(true);
                mqttConnectOptions.setUserName(prefs.getMqttUser());
                mqttConnectOptions.setPassword(prefs.getMqttPswd().toCharArray());

                mqttAndroidClient.connect(mqttConnectOptions, null, new IMqttActionListener() {
                    @Override
                    public void onSuccess(IMqttToken asyncActionToken) {
                        Log.d(TAG, "setupMQTT/onSuccess");
                        DisconnectedBufferOptions disconnectedBufferOptions = new DisconnectedBufferOptions();
                        disconnectedBufferOptions.setBufferEnabled(true);
                        disconnectedBufferOptions.setBufferSize(100);
                        disconnectedBufferOptions.setPersistBuffer(false);
                        disconnectedBufferOptions.setDeleteOldestMessages(true);
                        mqttAndroidClient.setBufferOpts(disconnectedBufferOptions);

                        // subscribe
                        mqttSubcribe(prefs.getClub() + "/" + id);
                    }

                    @Override
                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                        Log.e(TAG, "MQTT Connect failed:" + exception.toString());
                        exception.printStackTrace();
                        Toast.makeText(getApplicationContext(), exception.toString(), Toast.LENGTH_LONG).show();

                    }
                });
            }

        } catch (MqttException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }

    }


}
