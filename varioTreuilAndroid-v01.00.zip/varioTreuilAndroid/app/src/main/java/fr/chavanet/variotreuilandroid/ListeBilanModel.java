package fr.chavanet.variotreuilandroid;

public class ListeBilanModel {
    private String name;
    private String soloDay;
    private String biDay;
    private String handiDay;
    private String soloYear;
    private String biYear;
    private String handiYear;
    private String role;

    public ListeBilanModel(String name, String soloDay, String biDay, String handiDay, String soloYear, String biYear, String handiYear, String role) {
        this.name = name;
        this.soloDay = soloDay;
        this.biDay = biDay;
        this.handiDay = handiDay;
        this.soloYear = soloYear;
        this.biYear = biYear;
        this.handiYear = handiYear;
        this.role = role;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getSoloDay() {
        return soloDay;
    }
    public void setSoloDay(String nb) {
        this.soloDay = nb;
    }

    public String getSoloYear() {
        return soloYear;
    }
    public void setSoloYear(String nb) {
        this.soloYear = nb;
    }

    public String getBiDay() {
        return biDay;
    }
    public void setBiDay(String nb) {
        this.biDay = nb;
    }

    public String getBiYear() {
        return biYear;
    }
    public void setBiYear(String nb) {
        this.biYear = nb;
    }

    public String getHandiDay() {
        return handiDay;
    }
    public void setHandiDay(String nb) {
        this.handiDay = nb;
    }

    public String getHandiYear() {
        return handiYear;
    }
    public void setHandiYear(String nb) {
        this.handiYear = nb;
    }

    public String getRole() {
        return role = role;
    }


}