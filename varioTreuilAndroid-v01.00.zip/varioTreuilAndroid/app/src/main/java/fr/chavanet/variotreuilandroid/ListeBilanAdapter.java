package fr.chavanet.variotreuilandroid;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import androidx.core.content.ContextCompat;

public class ListeBilanAdapter extends ArrayAdapter<ListeBilanModel> {

    public ListeBilanAdapter(Context context, List<ListeBilanModel> item){
        super(context, 0, item);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null){
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.un_bilan, parent, false);
        }
        ItemViewHolder itemViewHolder = (ItemViewHolder) convertView.getTag();

        if(itemViewHolder == null){
            itemViewHolder = new ItemViewHolder();
            itemViewHolder.name = convertView.findViewById(R.id.name);
            itemViewHolder.soloToday = convertView.findViewById(R.id.soloToday);
            itemViewHolder.biToday = convertView.findViewById(R.id.biToday);
            itemViewHolder.handiToday = convertView.findViewById(R.id.handiToday);
            itemViewHolder.soloYear = convertView.findViewById(R.id.soloYear);
            itemViewHolder.biYear = convertView.findViewById(R.id.biYear);
            itemViewHolder.handiYear = convertView.findViewById(R.id.handiYear);
            itemViewHolder.role = convertView.findViewById(R.id.role);
            itemViewHolder.totalToday = convertView.findViewById(R.id.totalToday);
            itemViewHolder.totalYear = convertView.findViewById(R.id.totalYear);

            convertView.setTag(itemViewHolder);
        }

        ListeBilanModel item = getItem(position);
        itemViewHolder.name.setText(item.getName());
        itemViewHolder.soloToday.setText(item.getSoloDay());
        itemViewHolder.soloYear.setText(item.getSoloYear());
        itemViewHolder.biToday.setText(item.getBiDay());
        itemViewHolder.biYear.setText(item.getBiYear());
        itemViewHolder.handiToday.setText(item.getHandiDay());
        itemViewHolder.handiYear.setText(item.getHandiYear());
        itemViewHolder.role.setText(item.getRole());

        // Couleurs par role
        switch (item.getRole()) {
            case "Club" :
                itemViewHolder.name.setTextColor(ContextCompat.getColor(this.getContext(), R.color.colorPrimaryClub));
                itemViewHolder.role.setTextColor(ContextCompat.getColor(this.getContext(), R.color.colorPrimaryClub));
                itemViewHolder.totalToday.setTextColor(ContextCompat.getColor(this.getContext(), R.color.colorPrimaryClub));
                itemViewHolder.totalYear.setTextColor(ContextCompat.getColor(this.getContext(), R.color.colorPrimaryClub));
                break;
            case "Treuilleur" :
                itemViewHolder.name.setTextColor(ContextCompat.getColor(this.getContext(), R.color.colorPrimary));
                itemViewHolder.role.setTextColor(ContextCompat.getColor(this.getContext(), R.color.colorPrimary));
                itemViewHolder.totalToday.setTextColor(ContextCompat.getColor(this.getContext(), R.color.colorPrimary));
                itemViewHolder.totalYear.setTextColor(ContextCompat.getColor(this.getContext(), R.color.colorPrimary));
                break;
            default:
                itemViewHolder.name.setTextColor(ContextCompat.getColor(this.getContext(), R.color.colorGray));
                itemViewHolder.role.setTextColor(ContextCompat.getColor(this.getContext(), R.color.colorGray));
                itemViewHolder.totalToday.setTextColor(ContextCompat.getColor(this.getContext(), R.color.colorGray));
                itemViewHolder.totalYear.setTextColor(ContextCompat.getColor(this.getContext(), R.color.colorGray));
                break;
        }

        // Totaux
        Integer nb1; Integer nb2 ; Integer nb3;
        try { nb1  = Integer.parseInt(item.getSoloDay());} catch (Exception e) {nb1 = 0;}
        try { nb2 = Integer.parseInt(item.getBiDay());} catch (Exception e) {nb2 = 0;}
        try { nb3 =Integer.parseInt(item.getHandiDay());} catch (Exception e) {nb3 = 0;}
        Integer nb = nb1 + nb2 + nb3;
        itemViewHolder.totalToday.setText(nb.toString());

        try { nb1  = Integer.parseInt(item.getSoloYear());} catch (Exception e) {nb1 = 0;}
        try { nb2 = Integer.parseInt(item.getBiYear());} catch (Exception e) {nb2 = 0;}
        try { nb3 =Integer.parseInt(item.getHandiYear());} catch (Exception e) {nb3 = 0;}
        nb = nb1 + nb2 + nb3;
        itemViewHolder.totalYear.setText(nb.toString());

        return convertView;
    }

    private static class ItemViewHolder{
        public TextView name;
        public TextView soloToday;
        public TextView soloYear;
        public TextView biToday;
        public TextView biYear;
        public TextView handiToday;
        public TextView handiYear;
        public TextView role;
        public TextView totalToday;
        public TextView totalYear;
    }
}