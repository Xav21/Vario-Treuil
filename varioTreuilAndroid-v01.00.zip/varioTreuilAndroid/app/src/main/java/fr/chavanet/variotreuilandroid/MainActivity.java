package fr.chavanet.variotreuilandroid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity  {

    private static final String TAG = "xavier/MainActivity";
    private static final int REQUEST_ACTIVITY = 75;

    MainPagerAdapter mainPagerAdapter;
    ViewPager viewPager;

    // Les activités
    Intent intentPreferencesActivity;
    Intent intentAdvancedPreferencesActivity;
    Intent intentPiloteActivity;
    Intent intentBilanActivity;
    Intent intentAboutActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Init swipe
        viewPager = findViewById(R.id.viewMainPager);
        setPagerAdapter();

        // Init toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Les activités
        intentPreferencesActivity = new Intent(this, PreferencesActivity.class);
        intentAdvancedPreferencesActivity = new Intent(this, AdvancedPreferencesActivity.class);
        intentPiloteActivity = new Intent(this, PiloteActivity.class);
        intentBilanActivity = new Intent(this, BilanActivity.class);
        intentAboutActivity = new Intent(this, AboutActivity.class);

        Preferences prefs = new Preferences(this);
        if (prefs.getPilote() == "??" || prefs.getClub() == "??") {
            startActivityForResult(intentPreferencesActivity, REQUEST_ACTIVITY);
        }
    }

    private void setPagerAdapter(){
        mainPagerAdapter = new MainPagerAdapter(getSupportFragmentManager(),1,this);
        viewPager.setAdapter(mainPagerAdapter);
        mainPagerAdapter.notifyDataSetChanged();

        // Positionnement sur le dernier écran affiché
        Preferences prefs = new Preferences(this);
        if (prefs.isModePilote()) viewPager.setCurrentItem(0,true);
        else viewPager.setCurrentItem(1,true);
    }

    /***********************************************************************
     *  onCreateOptionsMenu
     ***********************************************************************/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Menu
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);

        return true;
    }
    /***********************************************************************
     *  onOptionsItemSelected
     ***********************************************************************/
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.bilan_treuil:
                startActivityForResult(intentBilanActivity, REQUEST_ACTIVITY);
                return true;
            case R.id.user_preference:
                startActivityForResult(intentPreferencesActivity, REQUEST_ACTIVITY);
                return true;
            case R.id.advanced_preferences:
                startActivityForResult(intentAdvancedPreferencesActivity, REQUEST_ACTIVITY);
                return true;
            case R.id.about:
                startActivityForResult(intentAboutActivity, REQUEST_ACTIVITY);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}