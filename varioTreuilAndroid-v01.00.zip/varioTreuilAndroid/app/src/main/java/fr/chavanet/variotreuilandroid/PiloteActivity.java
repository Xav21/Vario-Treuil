package fr.chavanet.variotreuilandroid;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.OnNmeaMessageListener;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import pl.pawelkleczkowski.customgauge.CustomGauge;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

@RequiresApi(api = Build.VERSION_CODES.N)
public class PiloteActivity extends AppCompatActivity implements OnNmeaMessageListener {
    private static final String TAG = "xavier/PiloteActivity";
    final int gpsAccessRequest = 1;

    // Screen objects
    TextView tvAltitude;
    TextView tvTx;
    TextView tvHauteur;
    TextView tvVoile;
    TextView tvptv;
    TextView tvPilote;
    TextView tvTypeVol;
    CustomGauge tvGauge;
    RadioButton tvActivite;

    // GPS
    LocationManager lm;
    LocationListener locationListener;
    int nbGpsRead = 0;
    double altQFE;
    boolean mneaAvailable = false;
    String typeGPS = "";

    // Gestion taux de montée
    double oldalt;
    long oldTime = System.currentTimeMillis();

    // Préférences
    Preferences pref;

    // Les paramètres
    String typeVol;
    String voile;
    Integer ptv;
    Boolean jk = false;

    // MQTT
    MqttAndroidClient mqttAndroidClient;

    /***********************************************************************
     *  onCreate
     ***********************************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate...");

        // Selection du theme et de la vue
        setTheme(R.style.piloteTheme);
        setContentView(R.layout.pilote_activity);

        // Préferences
        pref = new Preferences(getApplicationContext());

        // Récupération des paramètres
        Bundle b = getIntent().getExtras();
        if(b != null) {
            typeVol = b.getString("typeVol");
            voile = b.getString("voile");
            ptv = Integer.parseInt(b.getString("ptv"));
        }
        tvAltitude = findViewById (R.id.altitude);
        tvTx = findViewById (R.id.tx);
        tvHauteur = findViewById (R.id.hauteur);
        tvVoile = findViewById (R.id.voile);
        tvptv = findViewById (R.id.ptv);
        tvPilote = findViewById (R.id.pilote);
        tvTypeVol = findViewById (R.id.typeVol);
        tvGauge = findViewById(R.id.gaugePilote);
        tvActivite = findViewById(R.id.activite);

        // GPS
        Log.d(TAG, "onCreate GPS...");
        if (checkSelfPermission(ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[] {  ACCESS_FINE_LOCATION  }, gpsAccessRequest);
        }
        else {
            lm = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
            locationListener = new MyLocationListener();
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);

            // Mnea GPS data pour avoir l'altitude corrigée par la GEOIDE au lieu de la projectin wgs84.
            // Fonctionne à partir de l'API 30
            lm.addNmeaListener(this);
        }

        // Affichage caracteristiques
        tvPilote.setText(pref.getPilote());
        tvVoile.setText(voile);
        tvTypeVol.setText(typeVol);
        tvptv.setText(String.valueOf(ptv) + " kg");

        // Set QFE to 0
        tvHauteur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            // todo : A vérifier en fonctionnement réel
            altQFE = oldalt;
            }
        });

        // Cnx MQTT
        setupMQTT();

    }

    /***********************************************************************
     *  onStart
     ***********************************************************************/
    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG ,"onStart...");
        getWindow().setStatusBarColor(ContextCompat.getColor(getApplication(), R.color.colorPrimaryPilote));

    }
    /**
     * **********************************************************************
     * onDestroy
     * ***********************************************************************
     **/
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG ,"onDestroy...");
        lm.removeUpdates(locationListener);
        lm.removeNmeaListener(this);
        try {
            mqttAndroidClient.disconnect();
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    /**
     * **********************************************************************
     * onWindowFocusChanged
     * ***********************************************************************
     **/
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        Log.d(TAG ,"onWindowFocusChanged " + hasFocus);

    }
    /**
     * **********************************************************************
     * Gestion afficheur et envoi donnée
     * ***********************************************************************
     **/
    void displayAndSendData(Double alt,Double latitude, Double longitude,String typeGPS, Double HDOP, int nbSat){
        // gestion qfe
        if (nbGpsRead <= 10) {
            altQFE = alt;
            oldalt = alt;
        }
        nbGpsRead++;

        // calcul taux de montée
        Log.d(TAG,"oldalt=" + oldalt + " alt=" + alt + " oldtime=" + oldTime + " time=" + System.currentTimeMillis());
        double tx = ((alt -oldalt) / (System.currentTimeMillis() - oldTime) * 1000);

        oldTime = System.currentTimeMillis();
        oldalt = alt;

        // Envoi des données
        sendMQTTData((int)(alt - 0),(int) (alt - altQFE),tx, latitude, longitude,typeGPS,HDOP,nbSat);

        // Affichage
        tvAltitude.setText("QNH: " +Math.round(alt) + " m");
        tvHauteur.setText("QFE: " + Math.round(alt - altQFE) + " m");
        tx = (double) Math.round(tx*10) / 10;
        tvTx.setText(String.valueOf(tx));

        if (tx < 0 ) tx = 0.0;
        tvGauge.setValue((int)(tx*10));
    }
    /**
     * **********************************************************************
     * Listener class to get coordinates
     * ***********************************************************************
     **/
    private class MyLocationListener implements LocationListener {

        @Override
        public void onLocationChanged(Location loc) {
            Log.d(TAG,"MyLocationListener->" +  loc.getAltitude() + " " + loc.getLatitude() + " " + loc.getLongitude() );
            if (!mneaAvailable) displayAndSendData (loc.getAltitude(),loc.getLatitude(),loc.getLongitude(),"",null,-1);
        }

        @Override
        public void onProviderDisabled(String provider) {}

        @Override
        public void onProviderEnabled(String provider) {}

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {}
    }
    /**
     * **********************************************************************
     * Listener to get nmea GPS data and display it
     * Format nmea message
     *       $GNGGA,165819.00,4718.771268,N,00500.584520,E,1,12,0.5,250.4,M,48.0,M,,*75
     * ***********************************************************************
     **/
    @Override
    public void onNmeaMessage(String message, long timestamp) {
        mneaAvailable = true;
        mneaAvailable = true;
        GPSUtils gpsUtils = new GPSUtils(message);
        if (gpsUtils.isValid()){
            displayAndSendData (gpsUtils.getaltGPS(),gpsUtils.getLatGPS(),gpsUtils.getLongGPS(),gpsUtils.getTypeGPS(),gpsUtils.getHDOP(),gpsUtils.getNbSatellites());
        }
    }
    /***********************************************************************
     * sendMQTTData ()
     * ***********************************************************************
     **/
    void sendMQTTData(int qnh, int qfe, double tx, double latitude, double longitude,String typeGPS, Double hdop, Integer nbSat) {

        try {
            GPSUtils gu= new GPSUtils("");

            if (mqttAndroidClient.isConnected() && gu.getGPSQuality(hdop)) {
                MqttMessage message = new MqttMessage();

                // Formattage MQTT topic
                String topic = pref.getClub() + "/" + pref.getUniqueId();

                // Formattage message (payload)
                message.setQos(0);  // une seule fois
                JSONObject payload = new JSONObject();
                payload.put("id", pref.getUniqueId());
                payload.put("pilote", pref.getPilote());
                payload.put("qnh", qnh);
                payload.put("qfe", qfe);
                payload.put("tx", tx);
                payload.put("voile", voile);
                payload.put("ptv", ptv);
                payload.put("typevol", typeVol);
                payload.put("lat", latitude);
                payload.put("long", longitude);
                payload.put("typegps", typeGPS);
                payload.put("hdop", hdop);
                payload.put("nbsat", nbSat);
                payload.put("date", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
                message.setPayload(payload.toString().getBytes());
                Log.d(TAG, payload.toString());

                // Envoi MQTT
                mqttAndroidClient.publish(topic, message, null, new IMqttActionListener() {
                    @Override
                    public void onSuccess(IMqttToken asyncActionToken) {
                        if (jk) {
                            tvActivite.setChecked(false);
                            jk = false;
                        } else {
                            tvActivite.setChecked(true);
                            jk=true;
                        }
                    }

                    @Override
                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                        Log.e(TAG, "MQTT publish failed>" + asyncActionToken.getException().toString());
                        Toast.makeText(getApplicationContext(),asyncActionToken.getException().toString(),Toast.LENGTH_LONG).show();
                    }
                });
            }
        } catch (MqttException | JSONException e) {
            Log.e(TAG, e.toString());
            Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
        }

    }

    /**
     * **********************************************************************
     * setupMQTT
     * ***********************************************************************
     **/
    public void setupMQTT () {
        try {
            if (mqttAndroidClient == null || !mqttAndroidClient.isConnected()) {
                // Start MQTT
                String serverUri = "ssl://" + pref.getMqttServerName() + ":" + pref.getMqttServerPort();

                String clientId;
                clientId = pref.getUniqueId() + "pilote";
                Log.d(TAG, "setupMQTT=>" + serverUri + " " + clientId);

                mqttAndroidClient = new MqttAndroidClient(this, serverUri, clientId, new MemoryPersistence(), MqttAndroidClient.Ack.AUTO_ACK);
                MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
                mqttConnectOptions.setAutomaticReconnect(true);
                mqttConnectOptions.setCleanSession(true);
                mqttConnectOptions.setUserName(pref.getMqttUser());
                mqttConnectOptions.setPassword(pref.getMqttPswd().toCharArray());

                mqttAndroidClient.connect(mqttConnectOptions, null, new IMqttActionListener() {
                    @Override
                    public void onSuccess(IMqttToken asyncActionToken) {
                        Log.d(TAG, "setupMQTT/onSuccess");
                        DisconnectedBufferOptions disconnectedBufferOptions = new DisconnectedBufferOptions();
                        disconnectedBufferOptions.setBufferEnabled(true);
                        disconnectedBufferOptions.setBufferSize(100);
                        disconnectedBufferOptions.setPersistBuffer(false);
                        disconnectedBufferOptions.setDeleteOldestMessages(true);
                        mqttAndroidClient.setBufferOpts(disconnectedBufferOptions);
                    }

                    @Override
                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                        Log.e(TAG, "MQTT Connect failed:" + exception.toString());
                        exception.printStackTrace();
                        Toast.makeText(getApplicationContext(), exception.toString(), Toast.LENGTH_LONG).show();
                    }
                });
            }

        } catch (MqttException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
    }

}
