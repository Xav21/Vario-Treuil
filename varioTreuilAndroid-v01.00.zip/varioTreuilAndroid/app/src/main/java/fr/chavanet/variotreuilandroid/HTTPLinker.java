package fr.chavanet.variotreuilandroid;


import android.content.Context;
import android.content.SharedPreferences;

import androidx.preference.PreferenceManager;

class HTTPLinker {

    private String url;
    private String user;
    private String pswd;

    Context ctx;

    public HTTPLinker(Context context) {
        ctx = context;
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
        url = prefs.getString("prefsServerURL", "not set");
        user = prefs.getString("prefsServerUser", "not set");
        pswd = prefs.getString("prefsServerPassword", "not set");
    }

    public String getURL() {
        return "https://" + url + "/REST/";

    }
    public String getUser() {
        return user;

    }
    public String getPassword() {
        return pswd;

    }
}
