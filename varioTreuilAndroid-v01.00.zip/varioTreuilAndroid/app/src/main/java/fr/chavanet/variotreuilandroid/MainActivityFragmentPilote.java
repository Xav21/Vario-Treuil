package fr.chavanet.variotreuilandroid;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.UUID;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.preference.PreferenceManager;


public class MainActivityFragmentPilote extends Fragment  {

    static final String TAG = "xavier/MainFragmentPilote";
    private static final int REQUEST_ACTIVITY = 33;

    // Les activités
    Intent intentPiloteActivity;

    // screen obj
    Button startButton;
    RadioGroup radioButtonTypeVol;
    TextView tvLabelVoile;
    TextView tvLabelPTV;
    TextView tvLabelTypeVol;
    TextView tvVoile;
    TextView tvPtv;

    // Variables
    boolean voileSoloSelected = true;

    // Préférences
    Preferences prefs;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.activity_main_pilote, container, false);
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.i(TAG,  "onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG,  "onResume" );
        Toast.makeText(getContext(), "Mode pilote / vol sélectionné", Toast.LENGTH_SHORT).show();
        //getActivity().getWindow().setNavigationBarColor(ContextCompat.getColor(getContext(), R.color.colorPrimaryPilote));
        //getActivity().getWindow().setStatusBarColor(ContextCompat.getColor(getContext(), R.color.colorPrimaryPilote));
        //Toolbar tb = getActivity().findViewById(R.id.toolbar);
        //tb.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.colorPrimaryPilote));

        // Sauvegarde de l'activité active
        prefs = new Preferences(getContext());
        prefs.setModePilote();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Bundle args = getArguments();
        intentPiloteActivity = new Intent(getActivity(), PiloteActivity.class);

        // Chargement des préferences
        prefs = new Preferences(getContext());
        // screen obj
        tvVoile = view.findViewById(R.id.voileName);
        tvPtv = view.findViewById(R.id.poidTotalVolant);
        radioButtonTypeVol = view.findViewById(R.id.radioButtonTypeVol);
        tvLabelPTV = view.findViewById(R.id.labelPtv);
        tvLabelVoile = view.findViewById(R.id.labelVoile);
        tvLabelTypeVol = view.findViewById(R.id.textLabelTypeVol);

        // Bouton radio
        RadioButton rbSolo = view.findViewById(R.id.radioButton_volsolo);
        rbSolo.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        voileSoloSelected = true;
                        tvVoile.setText(prefs.getVoileSolo());
                        tvPtv.setText(String.valueOf(prefs.getPtvSolo()));
                    }
                });

        RadioButton rbBi = view.findViewById(R.id.radioButton_volbiplace);
        rbBi.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        voileSoloSelected = false;
                        tvVoile.setText(prefs.getVoileBiplace());
                        tvPtv.setText(String.valueOf(prefs.getPtvBiplace()));;
                    }
                });
        RadioButton rbHandi = view.findViewById(R.id.radioButton_volhandicare);
        rbHandi.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        voileSoloSelected = false;
                        tvVoile.setText(prefs.getVoileBiplace());
                        tvPtv.setText(String.valueOf(prefs.getPtvBiplace()));;
                    }
                });


        // Bouton démarrage
        startButton = view.findViewById(R.id.Start);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle b = new Bundle();
                int id = radioButtonTypeVol.getCheckedRadioButtonId();
                String typeVol = "";
                switch (id) {
                    case R.id.radioButton_volbiplace:
                        typeVol = "Biplace";
                        break;
                    case R.id.radioButton_volsolo:
                        typeVol = "Solo";
                        break;
                    case R.id.radioButton_volhandicare:
                        typeVol = "Hand'Icare";
                        break;
                }

                b.putString("typeVol", typeVol);
                b.putString("voile", tvVoile.getText().toString());
                b.putString("ptv", tvPtv.getText().toString());
                intentPiloteActivity.putExtras(b);
                startActivityForResult(intentPiloteActivity, REQUEST_ACTIVITY);
            }
        });

        if (voileSoloSelected) {
            tvVoile.setText(prefs.getVoileSolo());
            tvPtv.setText(String.valueOf(prefs.getPtvSolo()));
        } else {
            tvVoile.setText(prefs.getVoileBiplace());
            tvPtv.setText(String.valueOf(prefs.getPtvBiplace()));
        }


    }

}
