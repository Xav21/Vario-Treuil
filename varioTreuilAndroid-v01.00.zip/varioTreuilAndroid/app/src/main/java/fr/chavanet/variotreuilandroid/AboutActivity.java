package fr.chavanet.variotreuilandroid;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.util.Linkify;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    private static final String TAG = "xavier/AboutActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);

        //
        Date buildDate = new Date(BuildConfig.TIMESTAMP);
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy HH:mm");
        String sDate = sdf.format(buildDate.getTime());

        TextView tvAbout = findViewById(R.id.about);
        String txtAbout =
                "<h2><u>"+ getApplicationInfo().loadLabel(getPackageManager()).toString()+"</u></h2>" +
                "<p> version: V" + BuildConfig.VERSION_NAME + "</p>" +
                        "<p> identification: " + BuildConfig.APPLICATION_ID + "</p>" +
                        "<p> date de compilation: " + sDate + "</p>" +
                        "<p> contact: xavier.chavanet@free.fr</p><br>" +

                        "<h2><u>Mesures et calculs</u></h2>" +
                "<h4>Mode Pilote<h4><hr>" +
                "<li> <b>QNH</b> : altitude fournie par le GPS du téléphone du pilote. </li>" +
                "<li> <b>QFE</b> : hauteur calculée à partir du QNH. Mis à 0 au démarrage de l'application et ou cliquant sur <b>QFE</b> de l'écran pilote.</li>" +
                "<li> <b>Taux de montée</b> : calculé par le téléphone du pilote.</li>" +
                "<br>" +
                "<p>Ces mesures sont transmises au treuilleur dès la disponibilité de nouvelles coordonnées GPS (typiquement toutes les secondes).</p>" +
                "<p>Le nom du pilote, son PTV, sa voile & sa couleur et la qualité du signal GPS sont émis en même temps.</p>" +
                "<br>" +
                "<h4>Mode Treuilleur<h4>" +
                "<li> <b>Vitesse véhicule</b> : vitesse de déplacement du treuil fournie par le GPS du téléphone du treuilleur. </li>" +
                "<li> <b>Ligne déroulée & Angle ligne</b> : calculés à partir des positions GPS du pilote et du treuilleur et du QFE transmis par le pilote.</li>" +
                "<li> <b>Taux de montée, QNH, QFE</b> : transmis par le pilote.</li>" +
                "<br>" +
                "<h2><u>Limites d'utilisation</u></h2>" +
                "<p>Les mesures présentées sont soumises à la qualité de reception GPS et de la transmission du réseau 3/4/5G.</p> " +
                "La transmission et les calculs associés peuvent être interrompus à tout moment ou être de mauvaise qualité selon votre contexte géographique " +
                "<p>Le système Android peut, dans certains cas, limiter l'usage de cette application comme par exemple un système d'économie d'énergie. </p>" +
                "<br>" +
                "<p>Les mesures sont donc présentées à titre indicatif et ne peuvent en aucun cas servir de référence à l'action de treuillage." +
                "Le concepteur décline toute reponsabilité quand à une exploitation erronées des données présentées.</p>" +
                "<br><p></p>" +
                "<h2><u>Droits d'accès & vie privée</u></h2>" +
                "<p>Cette application demande les autorisations :" +
                "<li> ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION & ACCESS_BACKGROUND_LOCATION pour accéder aux coordonnées GPS</li>" +
                "<li> INTERNET & ACCESS_NETWORK_STATE pour l'échange des données.</li>" +
                "<li> WAKE_LOCK pour empêcher l'écran de s'éteindre en cours d'utilisation.</li></p>" +
                "<br>" +
                "<p> Les treuillées sont enregistrées à des fins statistiques incluant la date, le nom du pilote, sa voile et son ptv saisis dans l'application.</p>" +
                "<br>" +
                "<h2><u>Licence d'utilisation</u></h2>" +
                "<p>Cette application est publiée sous la licence <b>G.N.U.</a></b></p>" +
                "<p><b>GNU GENERAL PUBLIC LICENSE</b></p>" +
                "<p><b>Version 3 - 29 June 2007</b></p>" +
                "<p>https://www.gnu.org/licenses/gpl-3.0.fr.html</p>" +
                "<p>L'application est livrée sans garantie de fonctionnement <b>« as is »</b> conformément à la licence d'utilisation.</p>"
                ;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            tvAbout.setText(Html.fromHtml(txtAbout, Html.FROM_HTML_MODE_COMPACT));
        } else {
            tvAbout.setText(Html.fromHtml(txtAbout));
        }
    }

}

