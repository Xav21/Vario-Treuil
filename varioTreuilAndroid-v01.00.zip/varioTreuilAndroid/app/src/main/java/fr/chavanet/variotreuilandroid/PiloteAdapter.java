package fr.chavanet.variotreuilandroid;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PiloteAdapter extends ArrayAdapter<PiloteModel> {

    public PiloteAdapter(Context context, List<PiloteModel> item){
        super(context, 0, item);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null){
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.detail_pilote, parent, false);
        }
        ItemViewHolder itemViewHolder = (ItemViewHolder) convertView.getTag();

        if(itemViewHolder == null){
            itemViewHolder = new ItemViewHolder();
            itemViewHolder.pilote = convertView.findViewById(R.id.pilote);
            itemViewHolder.ptv = convertView.findViewById(R.id.ptv);
            itemViewHolder.voile = convertView.findViewById(R.id.voile);
            itemViewHolder.typeVol = convertView.findViewById(R.id.typeVol);

            convertView.setTag(itemViewHolder);
        }

        PiloteModel item = getItem(position);

        itemViewHolder.pilote.setText(item.getPilote());
        itemViewHolder.voile.setText(item.getVoile());
        itemViewHolder.ptv.setText(item.getPtv());
        itemViewHolder.typeVol.setText(item.getTypeVol());
        return convertView;
    }

    private static class ItemViewHolder{
        public TextView pilote;
        public TextView voile;
        public TextView ptv;
        public TextView typeVol;

    }
}