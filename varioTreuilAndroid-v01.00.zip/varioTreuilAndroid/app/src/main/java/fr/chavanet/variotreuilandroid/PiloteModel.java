package fr.chavanet.variotreuilandroid;

import androidx.recyclerview.widget.RecyclerView;

public class PiloteModel  {
    private String id;
    private String pilote;
    private String ptv;
    private String voile;
    private String typeVol;


    public PiloteModel(String id, String pilote, String ptv, String voile, String typeVol){
        this.id = id;
        this.pilote = pilote;
        this.ptv = ptv;
        this.voile = voile;
        this.typeVol = typeVol;

    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getPilote() {
        return pilote;
    }
    public void setPilote(String pilote) {
        this.pilote = pilote;
    }

    public String getPtv() { return ptv; }
    public void setPtv(String ptv ) {
        this.ptv = ptv;
    }

    public String getVoile() {
        return voile;
    }
    public void setVoile(String voile) {
        this.voile = voile;
    }

    public String getTypeVol() {
        return typeVol;
    }
    public void setTypeVol(String typeVol) {
        this.typeVol = typeVol;
    }
}