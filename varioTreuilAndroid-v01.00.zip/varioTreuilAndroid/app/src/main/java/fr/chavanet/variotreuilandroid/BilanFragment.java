package fr.chavanet.variotreuilandroid;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceManager;

import static com.android.volley.toolbox.Volley.newRequestQueue;

public class BilanFragment extends Fragment {

    static final String TAG = "xavier/BilanFragment";
    private RequestQueue mRequestQueue;
    private StringRequest mStringRequest;
    private String url = "";
    private String user;
    private String pswd;
    ListView lvlistebilan;
    List<ListeBilanModel> listeBilan = new ArrayList<>();
    ListeBilanAdapter listeBilanAdapter;
    String typeBilan;

    public BilanFragment(String type) {
        typeBilan = type;
    }

    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bilan_fragment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Bundle args = getArguments();

        // Gestion de la liste des bilans par pilote
        lvlistebilan = view.findViewById(R.id.listebilan);
        listeBilanAdapter = new ListeBilanAdapter(view.getContext(), listeBilan);
        lvlistebilan.setAdapter(listeBilanAdapter);

        // Lecture des données
        getData(view.getContext());
    }

    private void getData(final Context ctx) {
        Log.i(TAG, "SendData :" + url);
        mRequestQueue = newRequestQueue(ctx);

        // Construction de l'entête
        Preferences prefs = new Preferences(getContext());
        url = prefs.getServerName();
        user = prefs.getServerUser();
        pswd = prefs.getServerPswd();

        // Construction des paramètres
        final JSONObject jsonEnregistrement = new JSONObject();
        try {
            jsonEnregistrement.put("action",typeBilan);
            Date cDate = new Date();
            String fDate = new SimpleDateFormat("yyyy-MM-dd").format(cDate);
            jsonEnregistrement.put("date",fDate);
            jsonEnregistrement.put("club",prefs.getClub());
            jsonEnregistrement.put("iduser",prefs.getUniqueId());
            jsonEnregistrement.put("user",prefs.getPilote());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.i(TAG, jsonEnregistrement.toString());

        // Envoi de la requête
        mStringRequest = new StringRequest(Request.Method.POST, "https://" + url + "/REST/", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                listeBilan.clear();
                Log.i(TAG, response.toString());
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getInt("retCode") != 1) {
                        Toast.makeText(ctx,jsonResponse.getString("errorText"), Toast.LENGTH_LONG).show();
                    } else {
                        JSONObject datas = jsonResponse.getJSONObject("data");
                        Iterator<String> names = datas.keys();
                        while (names.hasNext()) {
                            String name = names.next();
                            JSONObject data = datas.getJSONObject(name);

                            JSONObject year = getJsonObject(data,"year");
                            String soloYear = getJsonValue (year,"Solo");
                            String biYear = getJsonValue (year,"Biplace");
                            String handiYear = getJsonValue (year,"Hand'Icare");

                            JSONObject day = getJsonObject(data,"day");
                            String soloDay = getJsonValue (day,"Solo");
                            String biDay = getJsonValue (day,"Biplace");
                            String handiDay = getJsonValue (day,"Hand'Icare");

                            String role = getJsonValue (data,"role");
                            listeBilan.add(new ListeBilanModel(name,soloDay,biDay,handiDay,soloYear, biYear, handiYear,role));
                            listeBilanAdapter.notifyDataSetChanged();
                        }
                    }
                }
                catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(ctx,e.toString()+ "->" +  response , Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i(TAG, "Erreur de lecture des donnéese :" + error.toString());
                Toast.makeText(ctx,"Erreur de lecture des données :" + error.toString(), Toast.LENGTH_LONG).show();
            }
        })
        {
            //This is for Headers If You Needed
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                String credentials = user + ":" + pswd ;
                String base64EncodedCredentials = Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Basic " + base64EncodedCredentials);
                return headers;
            }
            @Override
            public Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("param", jsonEnregistrement.toString());
                return params;
            };
        };

        mRequestQueue.add(mStringRequest);

    }
    private JSONObject getJsonObject (JSONObject jsonObject, String entry) {
        try {
            if (jsonObject == null ) return null;
            return jsonObject.getJSONObject(entry);
        } catch (JSONException e) {
            return null;
        }
    }
    private String getJsonValue (JSONObject jsonObject, String entry) {
        try {
            if (jsonObject == null ) return "-";
            return jsonObject.getString(entry);
        } catch (JSONException e) {
            return "-";
        }
    }


}
