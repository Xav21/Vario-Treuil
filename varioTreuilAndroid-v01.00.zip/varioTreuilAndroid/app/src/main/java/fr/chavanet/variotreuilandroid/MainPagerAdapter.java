package fr.chavanet.variotreuilandroid;

import android.app.Application;
import android.content.Context;
import android.view.MotionEvent;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

class MainPagerAdapter extends FragmentPagerAdapter {
    Context ctx;

    public MainPagerAdapter(@NonNull FragmentManager fm, int behavior, Context context) {
        super(fm, behavior);
        ctx = context;
    }


    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new MainActivityFragmentPilote();
            case 1:
                return new MainActivityFragmentTreuil(false);
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return 2;
    }

}
