package fr.chavanet.variotreuilandroid;

import android.app.Application;
import android.content.Context;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import android.content.SharedPreferences;
import android.util.Base64;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import androidx.preference.PreferenceManager;

import static com.android.volley.toolbox.Volley.newRequestQueue;

class StoreTreuillee {
    private static final String TAG = "xavier/SendHTTPData";
    private RequestQueue mRequestQueue;
    private StringRequest mStringRequest;
    private String url = "";
    private  String user;
    private  String pswd;
    Context ctx;


    public StoreTreuillee(Context context) {
        ctx = context;
        //RequestQueue initialized
        mRequestQueue = newRequestQueue(context);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        url = prefs.getString("prefsServerURL", "not set");
        user = prefs.getString("prefsServerUser", "not set");
        pswd = prefs.getString("prefsServerPassword", "not set");

    }
    public void sendData(final JSONObject jsonString) {
        Log.d(TAG, "SendData :" + url + "->" + jsonString);
        //String Request initialized
        mStringRequest = new StringRequest(Request.Method.POST, "https://" + url + "/REST/", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d(TAG, response.toString());
                try {
                    JSONObject jObject = new JSONObject(response);
                    if (jObject.getInt("retCode") != 1) {
                        Log.e(TAG, "Erreur d'enregistrement de la treuillée :" + jObject.getString("errorText"));
                        Toast.makeText(ctx,jObject.getString("errorText"), Toast.LENGTH_LONG).show();
                    } else {
                        //todo pas : A revoir
                        //Toast.makeText(ctx,"Treuillée enregistrée.", Toast.LENGTH_LONG).show();
                    }
                }
                catch (JSONException e) {
                    Log.e(TAG,e.toString());
                    e.printStackTrace();
                    Toast.makeText(ctx,e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Erreur d'enregistrement de la treuillée :" + error.toString());
                Toast.makeText(ctx,"Erreur d'enregistrement de la treuillée :" + error.toString(), Toast.LENGTH_LONG).show();
            }
        })
        {
            //This is for Headers If You Needed
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                String credentials = user + ":" + pswd ;
                String base64EncodedCredentials = Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Basic " + base64EncodedCredentials);
                return headers;
            }
            @Override
            public Map<String, String> getParams() throws com.android.volley.AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("param", jsonString.toString());
                return params;
            };
        };

        mRequestQueue.add(mStringRequest);

    }
}