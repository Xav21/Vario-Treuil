package fr.chavanet.variotreuilandroid;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.util.Objects;
import java.util.UUID;

import androidx.preference.PreferenceManager;

class Preferences {
    private static final String TAG = "xavier/Preferences";
    private SharedPreferences prefs;

    public Preferences(Context applicationContext) {
        prefs = PreferenceManager.getDefaultSharedPreferences(applicationContext);
    }

    public void setModePilote () {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("prefsModePilote", true);
        editor.commit();
    }
    public void setModeTreuil () {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("prefsModePilote", false);
        editor.commit();
    }

    public boolean isModePilote () {
        if (prefs.getBoolean("prefsModePilote",true)) return true;
        else return false;
    }
    public boolean isModeTreuil () {
        if (!prefs.getBoolean("prefsModePilote",true) ) return true;
        else return false;
    }

    public boolean isModeEnregistrement () {
        if (prefs.getBoolean("enregistrementTreuille",false) && getServerName() != "" ) return true;
        else return false;
    }

    public String getPilote () {
        return prefs.getString("prefsPilote", "??");
    }
    public String getClub () {
        return prefs.getString("prefsClub", "??");
    }
    public String getVoileSolo () {
        return prefs.getString("prefsVoileSolo", "??");
    }
    public Integer getPtvSolo () {
        return prefs.getInt("prefsPtvSolo", 85);
    }
    public String getVoileBiplace () {
        return prefs.getString("prefsVoileBiplace", "??");
    }
    public Integer getPtvBiplace () {
        return prefs.getInt("prefsPtvBiplace", 180);
    }

    public String getUniqueId () {
        String uniqueId =  prefs.getString("uniqueId", "");
        if (uniqueId.equals("")) {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("uniqueId", UUID.randomUUID().toString());
            editor.commit();
        }
        return prefs.getString("uniqueId", "");
    }

    public Integer getSeuilQFE (){
        return prefs.getInt("prefshauteurQFE", 50);
    }
    public Integer getSeuilTemps (){
        return prefs.getInt("prefsDelaiTreuillees", 30) * 1000;
    }
    public Integer getSeuilVitesseVoiture (){
        return prefs.getInt("prefsVitesseVehicule", 25);
    }
    public String getTreuileur (){
        return prefs.getString("prefsPilote", "??");
    }
    public Integer getDistanceMiniAffichage () {
        return prefs.getInt("prefsDistanceMiniAffichage", 00);
    }

    /******
     Server enregistrement treuillées
     *****/
    public String getServerName () {
        return prefs.getString("prefsServerURL", "");
    }
    public String getServerUser () {
        return prefs.getString("prefsServerUser", "not set");
    }
    public String getServerPswd () {
        return prefs.getString("prefsServerPassword", "not set");
    }
    /******
    MQTT
     *****/
    public String getMqttServerName () {
        return prefs.getString("mqttservername", "pixavier.chavanet.tk");
    }
    public Integer getMqttServerPort () {
        return Integer.parseInt(Objects.requireNonNull(prefs.getString("mqttserverport", "1885")));
    }
    public String getMqttUser () {
        return prefs.getString("mqttsuser", "FFVL");
    }
    public String getMqttPswd () {
        return prefs.getString("mqttpswd", "FFVL");
    }

}
