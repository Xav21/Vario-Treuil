package fr.chavanet.variotreuilandroid;

import android.util.Log;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
/*
 * Format nmea message
 *       $GNGGA,165819.00,4718.771268,N,00500.584520,E,1,12,0.5,250.4,M,48.0,M,,*75
 *       $GPGGA,135828.14,4718.771092,N,00500.584194,E,1,12,0.7,267.9,M,48.0,M,,*70
 *       https://fr.wikipedia.org/wiki/NMEA_0183
 */
class GPSUtils {
    private static final String TAG = "xavier/procedures";
    private String nmea;
    private String typeGPS;
    private String hdop;
    private String nbSatellites;
    private String altitude;
    private String latitude;
    private String longitude;

    private boolean validNmeaMessage = false;

    public GPSUtils(String nmeaMessage) {
        nmea = nmeaMessage.trim();
        validNmeaMessage = false;

        // Recherche trame xxGGA ex : $GNGGA,165819.00,4718.771268,N,00500.584520,E,1,12,0.5,250.4,M,48.0,M,,*75
        String paternText  = "^\\$([A-Z]{2})GGA,[0-9]{1,10}.[0-9]{1,10},([0-9]{4}.[0-9]{1,10}),[A-Z]{1},([0-9]{5}.[0-9]{1,10}),[A-Z]{1},1,([0-9]{1,5}),([0-9]{1,5}.[0-9]{1,5}),([0-9]{1,5}.[0-9]{1,5}).*";
        Pattern pattern = Pattern.compile(paternText);
        Matcher matcher = pattern.matcher(nmea);
        if(matcher.matches()) {
            Log.d(TAG,"GPSUtils >" + nmea + "->" + matcher.matches());
            validNmeaMessage = true;
            nmea = nmeaMessage;
            typeGPS = matcher.group(1);
            latitude = matcher.group(2);
            longitude = matcher.group(3);
            nbSatellites = matcher.group(4);
            hdop = matcher.group(5);
            altitude = matcher.group(6);
        }
    }
    public boolean isValid() {
        return validNmeaMessage;
    }

    public Double getaltGPS () {
        return Double.parseDouble(altitude);
    }

    public Double getLatGPS () {
        Double e = Double.parseDouble(latitude.substring(0,2));
        Double d = Double.parseDouble(latitude.substring(2)) / 60;
        return e + d;
    }
    public Double getLongGPS () {
        Double e = Double.parseDouble(longitude.substring(0,3));
        Double d = Double.parseDouble(longitude.substring(3)) / 60;
        return e + d;
    }
    public Double getHDOP () {
        return Double.parseDouble(hdop);
    }

    public String getGPSQualityText (Double hdop) {
        if (hdop == null ) {
            return "inconnue";}
        else if (hdop < 1) {
                return "optimale";
        } else if (hdop <= 2) {
            return "bonne";
        } else
            return "mauvaise";
        }

    public boolean getGPSQuality (Double hdop) {
        if (hdop == null ) return true;
        else if (hdop < 2) return true;
        else return false;
    }

    public int getNbSatellites () {
        return Integer.parseInt(nbSatellites);
    }
    public String getTypeGPS () {
        switch (typeGPS) {
            case "BD" :
            case "GB" :
                return "Beidou";
            case "GA" :
                return "Galileo";
            case "GP" :
                return "GPS";
            case "GL" :
                return "GLONASS";
            case "GN" :
                return "GPS + GLONASS";
            default:
                return "??";
        }
    }


}
